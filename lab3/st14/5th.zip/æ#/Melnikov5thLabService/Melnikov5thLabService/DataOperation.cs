﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Net;
using System.IO;
using System.Configuration;

namespace Melnikov5thLabService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    
    public class DataOperation : IDataOperation
    {
        private string urlStr = String.Empty;
        private List<BarcaPlayer> barcaPlayers = null;
        public DataOperation()
        {
            urlStr = String.Empty;
            barcaPlayers = new List<BarcaPlayer>();
            urlStr = System.Configuration.ConfigurationManager.AppSettings["adrs"] + "?student=" + System.Configuration.ConfigurationManager.AppSettings["studentNumber"];
        }
        public bool setUrlSettings(string addr, string stNum)
        {
            urlStr = addr + "?student=" + stNum;
            return true;
        }

        public BarcaPlayer[] loadRecords()
        {
            try 
            {
                barcaPlayers.Clear();
                StringBuilder url = new StringBuilder();
                url.AppendFormat(urlStr + "&act=show");
                WebRequest req = WebRequest.Create(url.ToString());
                WebResponse resp = req.GetResponse();
                Stream stream = resp.GetResponseStream();
                StreamReader sr = new StreamReader(stream);
                string Out = sr.ReadToEnd();
                string[] elements = Out.Split(new Char[] { '|' });
                for (int cnt = 0; cnt < elements.Length; cnt++)
                {
                    if (elements[cnt] == "")
                        continue;
                    string[] attr = elements[cnt].Split(new Char[] { '&' });

                    barcaPlayers.Add(new BarcaPlayer(attr[0], attr[1], attr[2], attr[3]));
                };

                sr.Close();
                return (BarcaPlayer[])barcaPlayers.ToArray();
            }
            catch
            {
                return null;
            }

        }

        public bool insertRecord(BarcaPlayer dr)
        {
            try
            {
                StringBuilder url = new StringBuilder();
                url.AppendFormat(urlStr + "&act=add&PlNum={0}&PlName={1}&PlPosition={2}&isCaptain={3}", dr.PlNumber, dr.PlName, dr.PlPosition, (dr.IsCaptain == true) ? "Yes" : "No");
                WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
                WebResponse resp = req.GetResponse();
                Stream stream = resp.GetResponseStream();
                StreamReader sr = new StreamReader(stream);
                string Out = sr.ReadToEnd();

                return (Out.Contains("<DMS>")) ?  true :  false;
            }
            catch
            {
                return false;
            }

        }

        public bool updateRecord(BarcaPlayer dr)
        {
            try
            {
                StringBuilder url = new StringBuilder();
                url.AppendFormat(urlStr + "&act=upd&PlNum={0}&PlName={1}&PlPosition={2}&isCaptain={3}", dr.PlNumber, dr.PlName, dr.PlPosition, (dr.IsCaptain == true) ? "Yes" : "No");
                WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
                WebResponse resp = req.GetResponse();
                Stream stream = resp.GetResponseStream();
                StreamReader sr = new StreamReader(stream);
                string Out = sr.ReadToEnd();

                return (Out.Contains("<DMS>")) ? true : false;
            }
            catch
            {
                return false;
            }
        }

        public bool deleteRecord(BarcaPlayer dr)
        {
            try
            {
                StringBuilder url = new StringBuilder();
                url.AppendFormat(urlStr + "&act=del&PlNum={0}", dr.PlNumber);
                WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
                WebResponse resp = req.GetResponse();
                Stream stream = resp.GetResponseStream();
                StreamReader sr = new StreamReader(stream);
                string Out = sr.ReadToEnd();

                return (Out.Contains("<DMS>")) ? true : false;
            }
            catch
            {
                return false;
            }
        }
    }
}
