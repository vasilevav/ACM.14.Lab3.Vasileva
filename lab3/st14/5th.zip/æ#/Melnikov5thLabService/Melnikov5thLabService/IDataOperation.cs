﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Melnikov5thLabService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IDataOperation
    {

        [OperationContract]
        bool setUrlSettings(string addr, string stNum);

        [OperationContract]
        BarcaPlayer[] loadRecords();

        [OperationContract]
        bool insertRecord(BarcaPlayer dr);

        [OperationContract]
        bool updateRecord(BarcaPlayer dr);

        [OperationContract]
        bool deleteRecord(BarcaPlayer dr);

    }

    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    // You can add XSD files into the project. After building the project, you can directly use the data types defined there, with the namespace "Melnikov5thLabService.ContractType".
    [DataContract]
    public class BarcaPlayer
    {
        public BarcaPlayer(string plNum, string plName, string plPos, string isCap)
        {
            PlNumber = plNum;
            PlName = plName;
            PlPosition = plPos;
            IsCaptain = (isCap.ToLower() == "yes" || isCap.ToLower() == "true") ? true : false; 
        }
        
        string plNumber = String.Empty;

        [DataMember]
        public string PlNumber
        {
          get { return plNumber; }
          set { plNumber = value; }
        }

        string plName = String.Empty;
        
        [DataMember]
        public string PlName
        {
          get { return plName; }
          set { plName = value; }
        }

        string plPosition = String.Empty;

        [DataMember]
        public string PlPosition
        {
          get { return plPosition; }
          set { plPosition = value; }
        }

        bool isCaptain = false;

        [DataMember]
        public bool IsCaptain
        {
          get { return isCaptain; }
          set { isCaptain = value; }
        }


    }
}
