﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Melnikov5thLabService;

namespace Melnikov5thLabHost
{
    public partial class DataOpService : ServiceBase
    {
        private ServiceHost myHost;
        public DataOpService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (myHost!=null)
            {
                myHost.Close();
            }

            myHost = new ServiceHost(typeof(DataOperation));

            myHost.Open();
        }

        protected override void OnStop()
        {
            if (myHost != null)
                myHost.Close();
        }
    }
}
