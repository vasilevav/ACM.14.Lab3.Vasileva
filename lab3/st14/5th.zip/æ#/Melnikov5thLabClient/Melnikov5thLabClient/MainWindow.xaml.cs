﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Melnikov5thLabClient.ServiceReference1;
using System.Configuration;
using System.Data;
//using System.Windows.Forms;

namespace Melnikov5thLabClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {

        public enum ActType { add, upd, del, undef };

        private List<BarcaPlayer> bPlList = null;
        private DataView dv = null;
        private DataTable dt = null;
        private Binding bTable = null;
        private DataOperationClient dOper = null;
        private ActType UserCurrentAction = ActType.undef;

        public MainWindow()
        {
            InitializeComponent();
            bPlList = new List<BarcaPlayer>();
            dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[] 
                                { 
                                    new DataColumn("PlNum", typeof(String)) { Caption = "Player number"}, 
                                    new DataColumn("PlName", typeof(String)) { Caption = "Player name"}, 
                                    new DataColumn("PlPos", typeof(String)) { Caption = "Player position"}, 
                                    new DataColumn("IsCap", typeof(Boolean)) { Caption = "Is capitan", } 
                                } );

            //bs = new System.Windows.Forms.BindingSource();
            //bs.DataSource = dt;
            //dv = new DataView(dt);
            //bTable = new Binding();
            //bTable.Source = dt;
            //bTable.Mode = BindingMode.OneWay;
            //this.BarcaPlGrid.SetBinding(BarcaPlGrid.ItemsSource, bTable);
            //this.BarcaPlGrid.SetBinding(BarcaPlGrid.Items., bTable);
            //BarcaPlGrid.ItemsSource = bs; 

            //BarcaPlGrid.ItemsSource = dt.AsDataView();
        }

        private async void MainWindow1_Loaded(object sender, RoutedEventArgs e)
        {
            dOper = new DataOperationClient("NetTcpBinding_IDataOperation");
            dOper.Open();//Open();
            await RefreshData(); 
            //dv = dt.AsDataView();
            //BarcaPlGrid.Items.Refresh();
        }

        private void MainWindow1_Unloaded(object sender, RoutedEventArgs e)
        {
            dOper.Close();
        }


        private void BarcaPlGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Смена выбранной записи
            // отобразить данные о записи на форму

        }

        private bool ReadDataFromForm (ref BarcaPlayer bPl)
        {
            try
            {
                Convert.ToInt32(tb_PlNum.Text);// проверка ввода числа
                bPl.PlNumber = tb_PlNum.Text;
                bPl.PlName = tb_PlName.Text;
                bPl.PlPosition = tb_PlPosition.Text;
                bPl.IsCaptain = cb_IsCaptain.IsChecked.Value;
                return true;
            }
            catch
            {
                MessageBox.Show("Ошибка при считывании данных игрока с формы! Проверьте корректность ввода!");
                return false;
            }
        }

        private async void btn_AcceptChanges_Click(object sender, RoutedEventArgs e)
        {

            if (UserCurrentAction != ActType.undef)
            {
                BarcaPlayer bPl = new BarcaPlayer();

                if (ReadDataFromForm(ref bPl) == false)
                    return;

                //ActType action = ActType.undef;
                //action = (bPlList.Exists(x => { return x.PlNumber == bPl.PlNumber; }) == true) ? ActType.upd : ActType.add;

                bool result = await ModifyData(UserCurrentAction, bPl);

                if (result == true)
                   await RefreshData();
                else
                    MessageBox.Show("Не удалось изменить данные!");

                UserCurrentAction = ActType.undef;
                ClearForm();
            }
            else
                MessageBox.Show("Не выбрано действие со списком! ");

             
        }



        private Task<bool> ModifyData(ActType actName, BarcaPlayer pl)
        {
            return Task.Run(() =>
            {
                    
                bool? res = null;
                switch (actName)
                {
                    case ActType.add:
                        res = dOper.insertRecord(pl);
                        break;
                    case ActType.upd:
                        res = dOper.updateRecord(pl);
                        break;
                    case ActType.del:
                        res = dOper.deleteRecord(pl);
                        break;
                };
                return (res == null) ? false : true;

            } );
        }


        private Task RefreshData()
        {
            return Task.Run(() =>
            {
                bPlList.Clear();
                dt.Rows.Clear();

                bPlList.AddRange(dOper.loadRecords());
                /*foreach (BarcaPlayer pl in bPlList)
                {

                    dt.Rows.Add(pl.PlNumber, pl.PlName, pl.PlPosition, pl.IsCaptain);

                }*/

                this.Dispatcher.Invoke(() => 
                    {
                        BarcaPlGrid.ItemsSource = null;
                        BarcaPlGrid.ItemsSource = (from el in bPlList
                                                   orderby Convert.ToInt16(el.PlNumber)
                                                   select new { PlayerNumber = el.PlNumber, PlayerName = el.PlName, PlayerPosition = el.PlPosition, IsCaptain = el.IsCaptain });
                        //BarcaPlGrid.ItemsSource = dt.AsDataView();
                    });
            });

        }



        private bool ShowDataOnForm()
        {
            try 
            {
                dynamic selBPl = BarcaPlGrid.SelectedItem;

                //DataRowView selBPl = (DataRowView)BarcaPlGrid.SelectedItem;
                string selNum = selBPl.PlayerNumber; //selBPl.Row.Field<string>("PlNum");
                if (bPlList.Exists(x => { return x.PlNumber == selNum; }) == true)
                {
                    BarcaPlayer tmpEl = bPlList.Find(x => { return x.PlNumber == selNum; });
                    tb_PlNum.Text = tmpEl.PlNumber;
                    tb_PlName.Text = tmpEl.PlName;
                    tb_PlPosition.Text = tmpEl.PlPosition;
                    cb_IsCaptain.IsChecked = tmpEl.IsCaptain;
                }

                return true;            
            }
            catch
            {
                return false;
            }

        }

        private void ClearForm()
        {
            tb_PlNum.Text = String.Empty;
            tb_PlName.Text = String.Empty;
            tb_PlPosition.Text = String.Empty;
            cb_IsCaptain.IsChecked = false;
        }

        private void cm_AddItem_Click(object sender, RoutedEventArgs e)
        {
            UserCurrentAction = ActType.add;
            ClearForm();
        }

        private void cm_DeleteItem_Click(object sender, RoutedEventArgs e)
        {
            if (BarcaPlGrid.SelectedIndex != -1)
            {
                UserCurrentAction = ActType.del;
                 ShowDataOnForm();
            }
            else
                MessageBox.Show("Выберите запись для изменения!");
        }

        private void cm_updItem_Click(object sender, RoutedEventArgs e)
        {
            if (BarcaPlGrid.SelectedIndex != -1)
            {
                UserCurrentAction = ActType.upd;
                ShowDataOnForm();
            }
            else
                MessageBox.Show("Выберите запись для изменения!");
        }


    }
}
