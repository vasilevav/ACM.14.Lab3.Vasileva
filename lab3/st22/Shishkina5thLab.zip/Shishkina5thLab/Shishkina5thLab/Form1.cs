﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Configuration;

namespace Shishkina5thLab
{
    public partial class Form1 : Form
    {
        private List<RoomItem> myRoomItems = null;
        private string studentNum = "";
        private string selfUrl = "";
        DataTable dt = null;
        BindingSource bs = null;
        public Form1()
        {
            InitializeComponent();
            myRoomItems = new List<RoomItem>();
            //gridMyItems.DataSource = myRoomItems;
            selfUrl = ConfigurationManager.AppSettings["selfurl"];
            studentNum = ConfigurationManager.AppSettings["studentNum"];

            DataColumn colName = new DataColumn("Name", Type.GetType("System.String") );

            DataColumn colColor = new DataColumn("Color", Type.GetType("System.String"));

            DataColumn colDesc = new DataColumn("Description", Type.GetType("System.String"));

            DataColumn colSBoolInd = new DataColumn("Some bool indicator", Type.GetType("System.String"));

            dt = new DataTable("myRoomItems");
            dt.Columns.AddRange(new DataColumn[] { colName, colColor, colDesc, colSBoolInd });

            bs = new BindingSource();
            bs.DataSource = dt;
            gridMyItems.DataSource = bs;

        }



        private void addDBItem()
        {
            StringBuilder url = new StringBuilder();
            url.AppendFormat(selfUrl + "?student=" + studentNum + "&isapp=1&action=1&nameEl={0}&colorEl={1}&descriptionEl={2}&SBoolInd={3}", insName.Text, insColor.Text, insDescription.Text, insBoolInd.Checked.ToString());
            WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
            WebResponse resp = req.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();
            insName.Text = insColor.Text = insDescription.Text = "";
        }

        private void editDBItem()
        {
            StringBuilder url = new StringBuilder();
            url.AppendFormat(selfUrl + "?student=" + studentNum + "&isapp=1&action=2&nameEl={0}&colorEl={1}&descriptionEl={2}&SBoolInd={3}", updName.Text, updColor.Text, updDescription.Text, updBoolInd.Checked.ToString());
            WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
            WebResponse resp = req.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();

            updName.Text = updColor.Text = updDescription.Text = "";
        }

        private void delDBItem()
        {
            StringBuilder url = new StringBuilder();
            url.AppendFormat(selfUrl + "?student=" + studentNum + "&isapp=1&action=3&nameEl={0}", delName.Text);
            WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
            WebResponse resp = req.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();
            delName.Text = "";
        }

        private void GetDataFromDB_Click(object sender, EventArgs e)
        {
            //запращиваем все элементы
            RefreshData();
        }

        private void RefreshData()
        {
           // gridMyItems.Rows.Clear();
            dt.Rows.Clear();
            myRoomItems.Clear();
            string url = selfUrl + "?student=" + studentNum + "&isapp=1&action=0";
            WebRequest req = WebRequest.Create(url);//Url + "?" + Data
            WebResponse resp = req.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();
            string[] elements = Out.Split(new Char[] { ';' });
            for (int cnt = 0; cnt < elements.Length; cnt++)
            {
                if (elements[cnt] == "")
                    continue;
                string[] attr = elements[cnt].Split(new Char[] { '_' });

                myRoomItems.Add(new RoomItem(attr[0], attr[1], attr[2], attr[3]));
                

            };
            
            foreach (RoomItem ri in myRoomItems)
            {
                dt.Rows.Add(ri.Name, ri.Color, ri.Description, ri.SBoolInd);


            }
            //gridMyItems.DataSource = myRoomItems;
     
           /* gridMyItems.Columns["Name"].DisplayIndex = 0;
            gridMyItems.Columns["Color"].DisplayIndex = 1;
            gridMyItems.Columns["Description"].DisplayIndex = 2;
            gridMyItems.Columns["Some"].DisplayIndex = 3;*/
            //gridMyItems.Refresh();
            sr.Close();
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            switch (tabControl1.SelectedTab.Name)
            {
                case "tabAdd":
                    addDBItem();
                    break;
                case "tabEdit":
                    editDBItem();
                    break;
                case "tabDel":
                    delDBItem();
                    break;
            }; 
            RefreshData();

        }

        private void gridMyItems_MouseClick(object sender, MouseEventArgs e)
        {
            if ( myRoomItems.Count == 0)
                return ;
            
            int currI = gridMyItems.SelectedRows[0].Index; // SelectedRows ;//Rows.SharedRow();
            updName.Text = myRoomItems[currI].Name;
            updColor.Text = myRoomItems[currI].Color;
            updDescription.Text = myRoomItems[currI].Description;
            if (myRoomItems[currI].SBoolInd == "true")
                updBoolInd.Checked = true; 
            else
                updBoolInd.Checked = false; 
            delName.Text = myRoomItems[currI].Name;
            
        }



    }
}
