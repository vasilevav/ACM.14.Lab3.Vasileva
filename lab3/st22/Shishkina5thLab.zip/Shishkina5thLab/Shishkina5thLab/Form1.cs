﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Configuration;

namespace Shishkina5thLab
{
    public partial class Form1 : Form
    {
        private List<RoomItem> myRoomItems = null;
        private string studentNum = "";
        private string selfUrl = "";
        public Form1()
        {
            InitializeComponent();
            myRoomItems = new List<RoomItem>();
            //gridMyItems.DataSource = myRoomItems;
            selfUrl = ConfigurationManager.AppSettings["selfurl"];
            studentNum = ConfigurationManager.AppSettings["studentNum"];
        }



        private void addDBItem()
        {
            StringBuilder url = new StringBuilder();
            url.AppendFormat(selfUrl + "?student=" + studentNum + "&isapp=1&action=1&nameEl={0}&colorEl={1}&descriptionEl={2}", insName.Text, insColor.Text, insDescription.Text);
            WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
            WebResponse resp = req.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();
            insName.Text = insColor.Text = insDescription.Text = "";
        }

        private void editDBItem()
        {
            StringBuilder url = new StringBuilder();
            url.AppendFormat(selfUrl + "?student=" + studentNum + "&isapp=1&action=2&nameEl={0}&colorEl={1}&descriptionEl={2}", updName.Text, updColor.Text, updDescription.Text);
            WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
            WebResponse resp = req.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();

            updName.Text = updColor.Text = updDescription.Text = "";
        }

        private void delDBItem()
        {
            StringBuilder url = new StringBuilder();
            url.AppendFormat(selfUrl + "?student=" + studentNum + "&isapp=1&action=3&nameEl={0}", delName.Text);
            WebRequest req = WebRequest.Create(url.ToString());//Url + "?" + Data
            WebResponse resp = req.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();
            delName.Text = "";
        }

        private void GetDataFromDB_Click(object sender, EventArgs e)
        {
            //запращиваем все элементы
            RefreshData();
        }

        private void RefreshData()
        {
            myRoomItems.Clear();
            string url = selfUrl + "?student=" + studentNum + "&isapp=1&action=0";
            WebRequest req = WebRequest.Create(url);//Url + "?" + Data
            WebResponse resp = req.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();
            string[] elements = Out.Split(new Char[] { ';' });
            for (int cnt = 0; cnt < elements.Length; cnt++)
            {
                if (elements[cnt] == "")
                    continue;
                string[] attr = elements[cnt].Split(new Char[] { '_' });
                myRoomItems.Add(new RoomItem(attr[0], attr[1], attr[2]));


            };
            //gridMyItems.Rows.Clear();
            gridMyItems.DataSource = myRoomItems;
            gridMyItems.Refresh();
            sr.Close();
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            switch (tabControl1.SelectedTab.Name)
            {
                case "tabAdd":
                    addDBItem();
                    break;
                case "tabEdit":
                    editDBItem();
                    break;
                case "tabDel":
                    delDBItem();
                    break;
            }; 
            RefreshData();

        }

        private void gridMyItems_MouseClick(object sender, MouseEventArgs e)
        {
            if (gridMyItems.SelectedRows[0].Index == null)
                return ;
            
            int currI = gridMyItems.SelectedRows[0].Index; // SelectedRows ;//Rows.SharedRow();
            updName.Text = myRoomItems[currI].Name;
            updColor.Text = myRoomItems[currI].Color;
            updDescription.Text = myRoomItems[currI].Description;

            delName.Text = myRoomItems[currI].Name;
            
        }

    }
}
