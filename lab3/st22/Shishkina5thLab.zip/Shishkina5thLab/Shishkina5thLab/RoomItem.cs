﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shishkina5thLab
{
    class RoomItem
    {
        public RoomItem(string nm, string cl, string desc )
        {
            Name = nm;
            Color = cl;
            Description = desc;
        }

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string color;

        public string Color
        {
            get { return color; }
            set { color = value; }
        }
        private string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }
    }
}
