﻿namespace Shishkina5thLab
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gridMyItems = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.GetDataFromDB = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabAdd = new System.Windows.Forms.TabPage();
            this.insDescription = new System.Windows.Forms.RichTextBox();
            this.insColor = new System.Windows.Forms.TextBox();
            this.insName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabEdit = new System.Windows.Forms.TabPage();
            this.updDescription = new System.Windows.Forms.RichTextBox();
            this.updColor = new System.Windows.Forms.TextBox();
            this.updName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabDel = new System.Windows.Forms.TabPage();
            this.delName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Confirm = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridMyItems)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabAdd.SuspendLayout();
            this.tabEdit.SuspendLayout();
            this.tabDel.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridMyItems
            // 
            this.gridMyItems.AllowUserToAddRows = false;
            this.gridMyItems.AllowUserToDeleteRows = false;
            this.gridMyItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridMyItems.Location = new System.Drawing.Point(12, 15);
            this.gridMyItems.MultiSelect = false;
            this.gridMyItems.Name = "gridMyItems";
            this.gridMyItems.ReadOnly = true;
            this.gridMyItems.RowTemplate.Height = 28;
            this.gridMyItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridMyItems.Size = new System.Drawing.Size(523, 435);
            this.gridMyItems.TabIndex = 0;
            this.gridMyItems.MouseClick += new System.Windows.Forms.MouseEventHandler(this.gridMyItems_MouseClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.gridMyItems);
            this.panel1.Controls.Add(this.GetDataFromDB);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(545, 502);
            this.panel1.TabIndex = 3;
            // 
            // GetDataFromDB
            // 
            this.GetDataFromDB.Location = new System.Drawing.Point(16, 459);
            this.GetDataFromDB.Name = "GetDataFromDB";
            this.GetDataFromDB.Size = new System.Drawing.Size(519, 36);
            this.GetDataFromDB.TabIndex = 1;
            this.GetDataFromDB.Text = "Загрузить картотеку из БД";
            this.GetDataFromDB.UseVisualStyleBackColor = true;
            this.GetDataFromDB.Click += new System.EventHandler(this.GetDataFromDB_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabAdd);
            this.tabControl1.Controls.Add(this.tabEdit);
            this.tabControl1.Controls.Add(this.tabDel);
            this.tabControl1.Location = new System.Drawing.Point(555, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(271, 450);
            this.tabControl1.TabIndex = 4;
            // 
            // tabAdd
            // 
            this.tabAdd.Controls.Add(this.insDescription);
            this.tabAdd.Controls.Add(this.insColor);
            this.tabAdd.Controls.Add(this.insName);
            this.tabAdd.Controls.Add(this.label3);
            this.tabAdd.Controls.Add(this.label2);
            this.tabAdd.Controls.Add(this.label1);
            this.tabAdd.Location = new System.Drawing.Point(4, 29);
            this.tabAdd.Name = "tabAdd";
            this.tabAdd.Padding = new System.Windows.Forms.Padding(3);
            this.tabAdd.Size = new System.Drawing.Size(263, 417);
            this.tabAdd.TabIndex = 0;
            this.tabAdd.Text = "Добавить";
            this.tabAdd.UseVisualStyleBackColor = true;
            // 
            // insDescription
            // 
            this.insDescription.Location = new System.Drawing.Point(15, 192);
            this.insDescription.Name = "insDescription";
            this.insDescription.Size = new System.Drawing.Size(233, 209);
            this.insDescription.TabIndex = 5;
            this.insDescription.Text = "";
            // 
            // insColor
            // 
            this.insColor.Location = new System.Drawing.Point(15, 112);
            this.insColor.Name = "insColor";
            this.insColor.Size = new System.Drawing.Size(233, 26);
            this.insColor.TabIndex = 4;
            // 
            // insName
            // 
            this.insName.Location = new System.Drawing.Point(15, 39);
            this.insName.Name = "insName";
            this.insName.Size = new System.Drawing.Size(233, 26);
            this.insName.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Description";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Color";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // tabEdit
            // 
            this.tabEdit.Controls.Add(this.updDescription);
            this.tabEdit.Controls.Add(this.updColor);
            this.tabEdit.Controls.Add(this.updName);
            this.tabEdit.Controls.Add(this.label5);
            this.tabEdit.Controls.Add(this.label6);
            this.tabEdit.Controls.Add(this.label7);
            this.tabEdit.Location = new System.Drawing.Point(4, 29);
            this.tabEdit.Name = "tabEdit";
            this.tabEdit.Padding = new System.Windows.Forms.Padding(3);
            this.tabEdit.Size = new System.Drawing.Size(263, 417);
            this.tabEdit.TabIndex = 1;
            this.tabEdit.Text = "Изменить";
            this.tabEdit.UseVisualStyleBackColor = true;
            // 
            // updDescription
            // 
            this.updDescription.Location = new System.Drawing.Point(15, 195);
            this.updDescription.Name = "updDescription";
            this.updDescription.Size = new System.Drawing.Size(233, 209);
            this.updDescription.TabIndex = 11;
            this.updDescription.Text = "";
            // 
            // updColor
            // 
            this.updColor.Location = new System.Drawing.Point(15, 115);
            this.updColor.Name = "updColor";
            this.updColor.Size = new System.Drawing.Size(233, 26);
            this.updColor.TabIndex = 10;
            // 
            // updName
            // 
            this.updName.Location = new System.Drawing.Point(15, 42);
            this.updName.Name = "updName";
            this.updName.ReadOnly = true;
            this.updName.Size = new System.Drawing.Size(233, 26);
            this.updName.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Color";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Name";
            // 
            // tabDel
            // 
            this.tabDel.Controls.Add(this.delName);
            this.tabDel.Controls.Add(this.label4);
            this.tabDel.Location = new System.Drawing.Point(4, 29);
            this.tabDel.Name = "tabDel";
            this.tabDel.Size = new System.Drawing.Size(263, 417);
            this.tabDel.TabIndex = 2;
            this.tabDel.Text = "Удалить";
            this.tabDel.UseVisualStyleBackColor = true;
            // 
            // delName
            // 
            this.delName.Location = new System.Drawing.Point(17, 49);
            this.delName.Name = "delName";
            this.delName.Size = new System.Drawing.Size(233, 26);
            this.delName.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Name";
            // 
            // Confirm
            // 
            this.Confirm.Location = new System.Drawing.Point(559, 460);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(263, 36);
            this.Confirm.TabIndex = 5;
            this.Confirm.Text = "Применить";
            this.Confirm.UseVisualStyleBackColor = true;
            this.Confirm.Click += new System.EventHandler(this.Confirm_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 502);
            this.Controls.Add(this.Confirm);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "5th lab";
            ((System.ComponentModel.ISupportInitialize)(this.gridMyItems)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabAdd.ResumeLayout(false);
            this.tabAdd.PerformLayout();
            this.tabEdit.ResumeLayout(false);
            this.tabEdit.PerformLayout();
            this.tabDel.ResumeLayout(false);
            this.tabDel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabAdd;
        private System.Windows.Forms.RichTextBox insDescription;
        private System.Windows.Forms.TextBox insColor;
        private System.Windows.Forms.TextBox insName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabEdit;
        private System.Windows.Forms.RichTextBox updDescription;
        private System.Windows.Forms.TextBox updColor;
        private System.Windows.Forms.TextBox updName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabDel;
        private System.Windows.Forms.TextBox delName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Confirm;
        private System.Windows.Forms.Button GetDataFromDB;
        public System.Windows.Forms.DataGridView gridMyItems;
    }
}

